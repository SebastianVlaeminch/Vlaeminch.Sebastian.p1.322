package vlaeminch.sebastian.p1.pkg322;

public class VlaeminchSebastianP1322 {
    
    public static void main(String[] args) {
        
        
        Box box = new Box();
        box.agregarPieza(new Motor("U-J12", "3", CondicionClimatica.LLUVIA, 3.12));
        box.agregarPieza(new Motor("U-J42", "7", CondicionClimatica.MIXTO, 3.4532));
        box.agregarPieza(new Ala("H-J4312", "0", CondicionClimatica.LLUVIA, 3));
        box.agregarPieza(new Ala("Hju-J12", "8", CondicionClimatica.SECO, 8));
        box.agregarPieza(new Neumatico("Hjulla-ujfe2", "43", CondicionClimatica.SECO, Compuesto.MEDIUM));
        box.agregarPieza(new Neumatico("9789gre2", "23", CondicionClimatica.LLUVIA, Compuesto.SOFT));
        
        //box.mostrarPiezas();
        //box.buscarPiezasPorCondicion(CondicionClimatica.SECO);
        box.ajustarPiezas();
        
     
        
        
        
    }
    
}
