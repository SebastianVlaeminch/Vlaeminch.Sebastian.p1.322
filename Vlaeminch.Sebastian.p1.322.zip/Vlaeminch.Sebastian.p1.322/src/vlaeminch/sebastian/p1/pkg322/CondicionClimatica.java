
package vlaeminch.sebastian.p1.pkg322;


public enum CondicionClimatica {
    SECO,
    LLUVIA,
    MIXTO;
}
