package vlaeminch.sebastian.p1.pkg322;


public class Ala extends Pieza implements Ajustable {
    
    private int cargaAerodinamica;

    public Ala(String nombre, String ubicacion, CondicionClimatica condicionClimatica, int cargaAerodinamica) {
        super(nombre, ubicacion, condicionClimatica);
        validarCargaAerodinamica(cargaAerodinamica);
        this.cargaAerodinamica = cargaAerodinamica;
    }

    
    private boolean validarCargaAerodinamica(int carga){
        boolean toreturn = true;
        if(carga > 10 || carga < 1){
            toreturn = false;
        }
        return toreturn;
    }
    
    @Override
    public void ajustar(){
        System.out.println("Ala siendo ajustado");
    }

    @Override
    public String toString() {
        return super.toString() + " Ala{" + "cargaAerodinamica=" + cargaAerodinamica + '}';
    }
    
    
    
}
