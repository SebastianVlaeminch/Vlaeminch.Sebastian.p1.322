package vlaeminch.sebastian.p1.pkg322;

public class Motor extends Pieza implements Ajustable {
    
    private double potanciaMaxima;

    public Motor(String nombre, String ubicacion, CondicionClimatica condicionClimatica, double potanciaMaxima) {
        super(nombre, ubicacion, condicionClimatica);
        this.potanciaMaxima = potanciaMaxima;
    }
    
    @Override
    public void ajustar(){
        System.out.println("Motor siendo ajustado");
    }

    @Override
    public String toString() {
        return super.toString() + " Motor{" + "potanciaMaxima=" + potanciaMaxima + '}';
    }
    
    

    
      
    
    
    
}
