package vlaeminch.sebastian.p1.pkg322;


public interface Ajustable {
    
    void ajustar();
}
