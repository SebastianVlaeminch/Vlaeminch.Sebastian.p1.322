package vlaeminch.sebastian.p1.pkg322;


public class Neumatico extends Pieza {
    
    private Compuesto compuesto;

    public Neumatico(String nombre, String ubicacion, CondicionClimatica condicionClimatica, Compuesto compuesto) {
        super(nombre, ubicacion, condicionClimatica);
        this.compuesto = compuesto;
    }

    @Override
    public String toString() {
        return super.toString() + " Neumatico{" + "compuesto=" + compuesto + '}';
    }

    

    
    
}
