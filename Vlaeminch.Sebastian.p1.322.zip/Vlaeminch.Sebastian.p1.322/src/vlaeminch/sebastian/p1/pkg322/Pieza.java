package vlaeminch.sebastian.p1.pkg322;

import java.util.Objects;


public abstract class Pieza {
    
    private String nombre;
    private String ubicacion;
    private CondicionClimatica condicionClimatica;

    public Pieza(String nombre, String ubicacion, CondicionClimatica condicionClimatica) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.condicionClimatica = condicionClimatica;
    }
    

    protected String getNombre() {
        return nombre;
    }

    protected String getUbicacion() {
        return ubicacion;
    }

    protected CondicionClimatica getCondicionClimatica() {
        return condicionClimatica;
    }

    @Override
    public String toString() {
        return "Pieza{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", condicionClimatica=" + condicionClimatica + '}';
    }
    
     
    @Override
    public boolean equals(Object o){
        if (o == this){
            return true;
        }
        if (o == null || !(o instanceof Pieza p)){
            return false;
        }
        return nombre.equals(p.nombre) && condicionClimatica.equals(p.condicionClimatica) && ubicacion.equals(p.ubicacion);
    }
    
     
    
    
    
    
    
    
}
