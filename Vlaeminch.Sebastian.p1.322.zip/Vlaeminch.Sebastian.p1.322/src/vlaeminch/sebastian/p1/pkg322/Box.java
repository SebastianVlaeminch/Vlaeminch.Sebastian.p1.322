package vlaeminch.sebastian.p1.pkg322;

import java.util.ArrayList;
import java.util.List;


public class Box {
    private List<Pieza> piezas;

    public Box() {
        this.piezas = new ArrayList<>();
    }
    
    public void checkNull(Pieza p){
        if (p == null){
            throw new IllegalArgumentException("Pieza nula nulo");
        }
    }
    
    
    public void agregarPieza(Pieza p){
        checkNull(p);
        if(!(EstaPiezaPorUbicacion(p.getUbicacion()))){
            throw new IllegalArgumentException("Ya se encuentra en la lista");
        }
        piezas.add(p); 
    }
    
    public void ajustarPiezas(){
        // deberia hacerse con un iterador, pero no tengo mas tiempo.
        for(Pieza p :piezas){
            if(p instanceof Ajustable a){
                a.ajustar();
        }
    }
        for(Pieza p :piezas){
            if(p instanceof Neumatico n){
                n.toString();
                System.out.println("No pudo ser ajustado, porque es un Neumatico");
            }
        }
    }
    
    public boolean EstaPiezaPorUbicacion(String ubicacion){
        boolean toReturn = true;
        for(Pieza p :piezas){
            if(p.getUbicacion().equals(ubicacion)){
                toReturn = false;
            }
        }
        return toReturn;
    }
    
    public void mostrarPiezas(){
        for(Pieza p :piezas){
            System.out.println(p.toString());
            System.out.println("\n");
        }
    }
    
    public void buscarPiezasPorCondicion(CondicionClimatica condicion){
        boolean alMenosUno = false;
        for(Pieza p :piezas){
            if(p.getCondicionClimatica().equals(condicion)){
                System.out.println(p.toString());
                System.out.println("\n");
                alMenosUno = true;
            }
        }
        if(alMenosUno == false){
            System.out.println("No se entontro Piezas con esa condicion");
        }
    }
    
    
    
}
